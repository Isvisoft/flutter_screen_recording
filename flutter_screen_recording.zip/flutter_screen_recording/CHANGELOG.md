## 1.0.0

* Update info pubsec.yaml
