#import <Flutter/Flutter.h>

@interface FlutterScreenRecordingPlugin : NSObject<FlutterPlugin>
@end
