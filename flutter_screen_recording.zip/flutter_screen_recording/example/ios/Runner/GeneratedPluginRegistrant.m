//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_screen_recording/FlutterScreenRecordingPlugin.h>)
#import <flutter_screen_recording/FlutterScreenRecordingPlugin.h>
#else
@import flutter_screen_recording;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterScreenRecordingPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterScreenRecordingPlugin"]];
}

@end
